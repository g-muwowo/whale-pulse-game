"""
Author: Given Muwowo
Class: Object Oriented Programming: Game Design
Date: 06/03/2026
Project: Final Game Project, whalePulse
File Name: signalPulse.py
Purpose: To define the SignalPulse class for the whalePulse game.
Higher Level Goal: To give the player a whale-signal ability that can destroy nets, slow disturbance, and make the game more active and exciting.
AI Usage Statement: I used AI as a learning tool while working on this project. I wrote and tested the code, made my own decisions about the game, and I am responsible for the final work.
"""

# ==== Import Statements ====
import pygame


# ========= Classes =========

class SignalPulse:
    """
    Represents an expanding whale signal pulse.
    The pulse is drawn as a ring that grows outward from the player.
    """

    def __init__(self, x, y):

        self.x = x
        self.y = y
        self.radius = 5
        self.maxRadius = 155
        self.growthSpeed = 5
        self.active = True

    # ===== Getter Methods =====

    def get_x(self):
        return self.x

    def get_y(self):
        return self.y

    def get_radius(self):
        return self.radius

    def get_active(self):
        return self.active

    # ===== Setter Methods =====

    def set_x(self, x):
        self.x = x

    def set_y(self, y):
        self.y = y

    def set_radius(self, radius):
        self.radius = radius

    def set_active(self, active):
        self.active = active

    # Update Method
    # Makes the pulse expand until it reaches its maximum size.
    def update(self):

        if self.active:
            self.radius += self.growthSpeed

            if self.radius >= self.maxRadius:
                self.active = False

    # Draw Method
    # Draws the pulse as expanding rings.
    def draw(self, screen):

        if self.active:

            pygame.draw.circle(
                screen,
                (180, 230, 255),
                (int(self.x), int(self.y)),
                int(self.radius),
                2
            )

            if self.radius > 20:
                pygame.draw.circle(
                    screen,
                    (100, 200, 255),
                    (int(self.x), int(self.y)),
                    int(self.radius - 18),
                    1
                )

    # Collision Method
    # Checks if the pulse ring has reached another object.
    def isColliding(self, other):
        dx = self.x - other.get_x()
        dy = self.y - other.get_y()
        distanceSquared = dx ** 2 + dy ** 2
        radiusSum = self.radius + other.get_radius()

        return distanceSquared < radiusSum ** 2

    # Affect Disturbance Method
    # Slows a disturbance if the pulse touches it.
    def affectDisturbance(self, disturbance):
        disturbance.slowDown()

    # Print Properties Method
    def printProperties(self):
        print("Signal Pulse Properties:")
        print("Position:", self.x, self.y)
        print("Radius:", self.radius)
        print("Max Radius:", self.maxRadius)
        print("Growth Speed:", self.growthSpeed)
        print("Active:", self.active)


# ========= Testing =========

if __name__ == "__main__":
    p1 = SignalPulse(100, 100)
    p1.printProperties()


# Thank you for reading the code. The author would appreciate your feedback.