"""
Author: Given Muwowo
Class: Object Oriented Programming: Game Design
Date: 06/03/2026
Project: Final Game Project, whalePulse
File Name: disturbanceAgent.py
Purpose: To define the DisturbanceAgent class for the whalePulse game.
Higher Level Goal: To represent harmful disturbance in the whale ecosystem, such as boats, noise, pressure, or other human-related disruption.
AI Usage Statement: I used AI as a learning tool while working on this project. I wrote and tested the code, made my own decisions about the game, and I am responsible for the final work.
"""

# ==== Import Statements ====
import pygame
from agent import Agent


# ========= Classes =========

class DisturbanceAgent(Agent):
    """
    Represents a harmful disturbance in the whale ecosystem.
    It is drawn as a red abstract shape instead of a realistic boat or object.
    """

    def __init__(self, x, y, color=(255, 80, 80), radius=24):

        super().__init__(x, y, color, radius)

        self.vx = 2.0
        self.vy = 1.2
        self.damageAmount = 12

        self.slowTimer = 0
        self.normalVx = self.vx
        self.normalVy = self.vy

    # ===== Getter Methods =====

    def get_damageAmount(self):
        return self.damageAmount

    def get_slowTimer(self):
        return self.slowTimer

    # ===== Setter Methods =====

    def set_damageAmount(self, damageAmount):
        self.damageAmount = damageAmount

    def set_slowTimer(self, slowTimer):
        self.slowTimer = slowTimer

    # Move Method
    # Moves disturbance across the screen and bounces at screen edges.
    def move(self, screen):
        self.x += self.vx
        self.y += self.vy
        self.bounceOnEdges(screen)

    # Update Method
    # If slowed by a signal pulse, count down the slow effect.
    def update(self, screen):

        if self.slowTimer > 0:
            self.slowTimer -= 1

            if self.slowTimer == 0:
                self.vx = self.normalVx
                self.vy = self.normalVy

        self.move(screen)

    # Draw Method
    # Draws disturbance as a jagged red shape to suggest noise, danger, or pressure.
    def draw(self, screen):

        pygame.draw.rect(
            screen,
            self.color,
            (
                int(self.x - self.radius),
                int(self.y - self.radius // 2),
                int(self.radius * 2),
                int(self.radius)
            )
        )

        points = [
            (int(self.x - self.radius), int(self.y - self.radius // 2)),
            (int(self.x - self.radius // 2), int(self.y - self.radius)),
            (int(self.x), int(self.y - self.radius // 2)),
            (int(self.x + self.radius // 2), int(self.y - self.radius)),
            (int(self.x + self.radius), int(self.y - self.radius // 2)),
            (int(self.x + self.radius), int(self.y + self.radius // 2)),
            (int(self.x + self.radius // 2), int(self.y + self.radius)),
            (int(self.x), int(self.y + self.radius // 2)),
            (int(self.x - self.radius // 2), int(self.y + self.radius)),
            (int(self.x - self.radius), int(self.y + self.radius // 2))
        ]

        pygame.draw.lines(screen, (255, 180, 180), True, points, 2)

    # Damage Method
    # Lowers the player whale's well-being.
    def damagePlayer(self, player):
        player.takeDamage(self.damageAmount)

    # Slow Method
    # Slows the disturbance after it is touched by a signal pulse.
    def slowDown(self):

        if self.slowTimer <= 0:
            self.normalVx = self.vx
            self.normalVy = self.vy

        self.vx = self.normalVx * 0.35
        self.vy = self.normalVy * 0.35
        self.slowTimer = 120

    # Speed Up Method
    # Makes the disturbance more dangerous in later waves.
    def speedUp(self, amount=1.2):
        self.vx *= amount
        self.vy *= amount
        self.normalVx = self.vx
        self.normalVy = self.vy

    # Print Properties Method
    def printProperties(self):
        print("Disturbance Agent Properties:")
        print("Position:", self.x, self.y)
        print("Velocity:", self.vx, self.vy)
        print("Color:", self.color)
        print("Radius:", self.radius)
        print("Damage Amount:", self.damageAmount)
        print("Slow Timer:", self.slowTimer)


# ========= Testing =========

if __name__ == "__main__":
    d1 = DisturbanceAgent(300, 200)
    d1.printProperties()


# Thank you for reading the code. The author would appreciate your feedback.