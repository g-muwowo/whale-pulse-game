"""
Author: Given Muwowo
Class: Object Oriented Programming: Game Design
Date: 06/03/2026
Project: Final Game Project, whalePulse
File Name: whaleAgent.py
Purpose: To define the WhaleAgent class for the whalePulse game.
Higher Level Goal: To create a supportive non-player agent that gives the player limited well-being support while keeping the game readable and shape-based.
AI Usage Statement: I used AI as a learning tool while working on this project. I wrote and tested the code, made my own decisions about the game, and I am responsible for the final work.
"""

# ==== Import Statements ====
import pygame
from agent import Agent


# ========= Classes =========

class WhaleAgent(Agent):
    """
    Represents a supportive non-player whale or support presence in the ecosystem.
    It is drawn as a simple green shape instead of a realistic whale image.
    """

    def __init__(self, x, y, color=(0, 255, 150), radius=24):

        super().__init__(x, y, color, radius)

        self.vx = 0.7
        self.vy = 0.4
        self.supportAmount = 2

    # ===== Getter Methods =====

    def get_supportAmount(self):
        return self.supportAmount

    # ===== Setter Methods =====

    def set_supportAmount(self, supportAmount):
        self.supportAmount = supportAmount

    # Move Method
    # Moves the support agent and bounces it off screen edges.
    def move(self, screen):
        self.x += self.vx
        self.y += self.vy
        self.bounceOnEdges(screen)

    # Update Method
    # This supports polymorphism because the game can call update()
    # on all agents, even when each class updates differently.
    def update(self, screen):
        self.move(screen)

    # Draw Method
    # Draws the support agent as a green circle with a ring.
    def draw(self, screen):

        # Support ring
        pygame.draw.circle(
            screen,
            (120, 255, 200),
            (int(self.x), int(self.y)),
            int(self.radius + 8),
            2
        )

        # Main body
        pygame.draw.circle(
            screen,
            self.color,
            (int(self.x), int(self.y)),
            int(self.radius)
        )

        # Center glow
        pygame.draw.circle(
            screen,
            (255, 255, 255),
            (int(self.x), int(self.y)),
            4
        )

    # Support Method
    # Adds a small amount of well-being to the player.
    def supportPlayer(self, player):
        player.heal(self.supportAmount)

    # Print Properties Method
    def printProperties(self):
        print("Whale Agent Properties:")
        print("Position:", self.x, self.y)
        print("Velocity:", self.vx, self.vy)
        print("Color:", self.color)
        print("Radius:", self.radius)
        print("Support Amount:", self.supportAmount)


# ========= Testing =========

if __name__ == "__main__":
    w1 = WhaleAgent(100, 100)
    w1.printProperties()


# Thank you for reading the code. The author would appreciate your feedback.