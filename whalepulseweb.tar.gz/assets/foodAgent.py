"""
Author: Given Muwowo
Class: Object Oriented Programming: Game Design
Date: 06/03/2026
Project: Final Game Project, whalePulse
File Name: foodAgent.py
Purpose: To define the FoodAgent class for the whalePulse game.
Higher Level Goal: To give the player clear objects to collect so the game has score, movement goals, risk, reward, and replay value.
AI Usage Statement: I used AI as a learning tool while working on this project. I wrote and tested the code, made my own decisions about the game, and I am responsible for the final work.
"""

# ==== Import Statements ====
import pygame
import random
from agent import Agent


# ========= Classes =========

class FoodAgent(Agent):
    """
    Represents food, krill, or energy in the whale ecosystem.
    The player collects it to increase score.
    Some food becomes golden and worth more.
    """

    def __init__(self, x, y, color=(255, 220, 0), radius=10):

        super().__init__(x, y, color, radius)

        self.scoreValue = 1
        self.healAmount = 0
        self.isGolden = False

        self.vx = 0
        self.vy = 0

    # ===== Getter Methods =====

    def get_scoreValue(self):
        return self.scoreValue

    def get_healAmount(self):
        return self.healAmount

    def get_isGolden(self):
        return self.isGolden

    # ===== Setter Methods =====

    def set_scoreValue(self, scoreValue):
        self.scoreValue = scoreValue

    def set_healAmount(self, healAmount):
        self.healAmount = healAmount

    def set_isGolden(self, isGolden):
        self.isGolden = isGolden

    # Update Method
    # Food does not move, but it still has update() for polymorphism.
    def update(self, screen):
        pass

    # Draw Method
    # Draws normal food as yellow and rare food as golden.
    def draw(self, screen):

        if self.isGolden:
            ringColor = (255, 255, 180)
            bodyColor = (255, 190, 0)
            ringWidth = 3
            extraRadius = 8

        else:
            ringColor = (255, 245, 150)
            bodyColor = self.color
            ringWidth = 2
            extraRadius = 5

        pygame.draw.circle(
            screen,
            ringColor,
            (int(self.x), int(self.y)),
            int(self.radius + extraRadius),
            ringWidth
        )

        pygame.draw.circle(
            screen,
            bodyColor,
            (int(self.x), int(self.y)),
            int(self.radius)
        )

    # Collect Method
    # Gives score and optional healing, then respawns the food.
    def collect(self, player, screen):

        points = self.scoreValue

        player.addScore(points)

        if self.healAmount > 0:
            player.heal(self.healAmount)

        self.respawn(screen)

        return points

    # Respawn Method
    # Moves food to a random position and sometimes turns it golden.
    def respawn(self, screen):
        screenWidth, screenHeight = screen.get_size()

        margin = 60

        self.x = random.randint(margin, max(margin, screenWidth - margin))
        self.y = random.randint(margin, max(margin, screenHeight - margin))

        # Sometimes become golden food.
        if random.random() < 0.18:
            self.isGolden = True
            self.scoreValue = 5
            self.radius = 13

        else:
            self.isGolden = False
            self.scoreValue = 1
            self.radius = 10

    # Print Properties Method
    def printProperties(self):
        print("Food Agent Properties:")
        print("Position:", self.x, self.y)
        print("Color:", self.color)
        print("Radius:", self.radius)
        print("Score Value:", self.scoreValue)
        print("Heal Amount:", self.healAmount)
        print("Golden:", self.isGolden)


# ========= Testing =========

if __name__ == "__main__":
    f1 = FoodAgent(200, 200)
    f1.printProperties()


# Thank you for reading the code. The author would appreciate your feedback.