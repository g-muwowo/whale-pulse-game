"""
Author: Given Muwowo
Class: Object Oriented Programming: Game Design
Date: 06/03/2026
Project: Final Game Project, whalePulse
File Name: floatingText.py
Purpose: To define the FloatingText class for the whalePulse game.
Higher Level Goal: To give the player quick visual feedback when they score, survive waves, destroy nets, or create streaks.
AI Usage Statement: I used AI as a learning tool while working on this project. I wrote and tested the code, made my own decisions about the game, and I am responsible for the final work.
"""

# ==== Import Statements ====
import pygame


# ========= Classes =========

class FloatingText:
    """
    Represents temporary text that floats upward and disappears.
    This gives the game more feedback and celebration.
    """

    def __init__(self, x, y, message, color=(255, 255, 255), life=70):

        self.x = x
        self.y = y
        self.message = message
        self.color = color
        self.life = life
        self.maxLife = life
        self.active = True

    # ===== Getter Methods =====

    def get_active(self):
        return self.active

    # Update Method
    # Moves the text upward and removes it after its life runs out.
    def update(self):

        self.y -= 0.7
        self.life -= 1

        if self.life <= 0:
            self.active = False

    # Draw Method
    # Draws the text on the screen.
    def draw(self, screen, font):

        if self.active:
            text = font.render(self.message, True, self.color)
            screen.blit(text, (int(self.x), int(self.y)))

    # Print Properties Method
    def printProperties(self):
        print("Floating Text Properties:")
        print("Position:", self.x, self.y)
        print("Message:", self.message)
        print("Life:", self.life)
        print("Active:", self.active)


# ========= Testing =========

if __name__ == "__main__":
    t1 = FloatingText(100, 100, "+1")
    t1.printProperties()


# Thank you for reading the code. The author would appreciate your feedback.