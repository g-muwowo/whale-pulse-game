"""
Author: Given Muwowo
Class: Object Oriented Programming: Game Design
Date: 06/03/2026
Project: Final Game Project, WhalePulseWeb
File Name: main.py
Purpose: To start the web version of the WhalePulse game.
Higher Level Goal: To keep the startup file simple while making the game compatible with browser play through Pygbag.
AI Usage Statement: I used AI as a learning tool while working on this project. I wrote and tested the code, made my own decisions about the game, and I am responsible for the final work.
"""

# ==== Import Statements ====
import asyncio
import pygame
from game import Game


# ===== Functions =====

async def main():
    """
    Main function creates a Game object and runs the game in a browser-friendly way.
    Importing pygame here helps Pygbag detect and load the pygame package.
    """

    game = Game()
    await game.run()


if __name__ == "__main__":
    asyncio.run(main())


# Thank you for reading the code. The author would appreciate your feedback.