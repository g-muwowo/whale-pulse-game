"""
Author: Given Muwowo
Class: Object Oriented Programming: Game Design
Date: 06/03/2026
Project: Final Game Project, whalePulse
File Name: agent.py
Purpose: To define the Agent base class for the whalePulse game.
Higher Level Goal: To create a shared structure for different game objects so that agents can be added, removed, or changed without breaking the main game loop.
AI Usage Statement: I used AI as a learning tool while working on this project. I wrote and tested the code, made my own decisions about the game, and I am responsible for the final work.
"""

# ==== Import Statements ====
import pygame
import math


# ========= Classes =========

class Agent:
    """
    Represents a basic object in the whale ecosystem.
    Other game objects can inherit from this class.
    """

    def __init__(self, x, y, color=(255, 255, 255), radius=20):

        self.x = x
        self.y = y
        self.color = color
        self.radius = radius
        self.vx = 0.5
        self.vy = 0.5

    # ===== Getter Methods =====

    def get_x(self):
        return self.x

    def get_y(self):
        return self.y

    def get_color(self):
        return self.color

    def get_radius(self):
        return self.radius

    def get_vx(self):
        return self.vx

    def get_vy(self):
        return self.vy

    # ===== Setter Methods =====

    def set_x(self, x):
        self.x = x

    def set_y(self, y):
        self.y = y

    def set_color(self, color):
        self.color = color

    def set_radius(self, radius):
        self.radius = radius

    def set_vx(self, vx):
        self.vx = vx

    def set_vy(self, vy):
        self.vy = vy

    # Move Method
    # Basic movement for an agent.
    # Child classes can override this method with different movement behavior.
    def move(self, screen):
        self.x += self.vx
        self.y += self.vy

    # Update Method
    # Shared method that can be called by the game loop.
    # This supports polymorphism because different child classes can update differently.
    def update(self, screen):
        self.move(screen)

    # Draw Method
    # Draws the agent as a circle on the screen.
    # Child classes can override this method to draw different shapes.
    def draw(self, screen):
        pygame.draw.circle(
            screen,
            self.color,
            (int(self.x), int(self.y)),
            int(self.radius)
        )

    # Collision Method
    # Checks if this agent is colliding with another circular object.
    def isColliding(self, other):
        dx = self.x - other.get_x()
        dy = self.y - other.get_y()
        distanceSquared = dx ** 2 + dy ** 2
        radiusSum = self.radius + other.get_radius()

        return distanceSquared < radiusSum ** 2

    # Distance Method
    # Gives the distance between this agent and another object.
    def distanceTo(self, other):
        dx = self.x - other.get_x()
        dy = self.y - other.get_y()

        return math.sqrt(dx ** 2 + dy ** 2)

    # Boundary Method
    # Keeps the agent inside the screen.
    def stayOnScreen(self, screen):
        screenWidth, screenHeight = screen.get_size()

        if self.x - self.radius < 0:
            self.x = self.radius

        if self.x + self.radius > screenWidth:
            self.x = screenWidth - self.radius

        if self.y - self.radius < 0:
            self.y = self.radius

        if self.y + self.radius > screenHeight:
            self.y = screenHeight - self.radius

    # Bounce Method
    # Makes an agent bounce off the screen edges.
    def bounceOnEdges(self, screen):
        screenWidth, screenHeight = screen.get_size()

        if self.x - self.radius <= 0 or self.x + self.radius >= screenWidth:
            self.vx *= -1

        if self.y - self.radius <= 0 or self.y + self.radius >= screenHeight:
            self.vy *= -1

    # Print Properties Method
    def printProperties(self):
        print("Agent Properties:")
        print("Position:", self.x, self.y)
        print("Velocity:", self.vx, self.vy)
        print("Color:", self.color)
        print("Radius:", self.radius)


# ========= Testing =========

if __name__ == "__main__":
    a1 = Agent(100, 100, (0, 0, 255), 25)
    a1.printProperties()


# Thank you for reading the code. The author would appreciate your feedback.