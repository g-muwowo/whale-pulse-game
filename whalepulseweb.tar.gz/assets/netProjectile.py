"""
Author: Given Muwowo
Class: Object Oriented Programming: Game Design
Date: 06/03/2026
Project: Final Game Project, whalePulse
File Name: netProjectile.py
Purpose: To define the NetProjectile class for the whalePulse game.
Higher Level Goal: To add active danger by creating moving obstacles that can hurt the player and can be destroyed by the signal pulse.
AI Usage Statement: I used AI as a learning tool while working on this project. I wrote and tested the code, made my own decisions about the game, and I am responsible for the final work.
"""

# ==== Import Statements ====
import pygame
from agent import Agent


# ========= Classes =========

class NetProjectile(Agent):
    """
    Represents a harmful net/noise projectile moving across the ocean.
    It gives the player a reason to use the signal pulse.
    """

    def __init__(self, x, y, vx, vy, color=(190, 190, 190), radius=12):

        super().__init__(x, y, color, radius)

        self.vx = vx
        self.vy = vy
        self.damageAmount = 18
        self.active = True

    # ===== Getter Methods =====

    def get_active(self):
        return self.active

    def get_damageAmount(self):
        return self.damageAmount

    # ===== Setter Methods =====

    def set_active(self, active):
        self.active = active

    def set_damageAmount(self, damageAmount):
        self.damageAmount = damageAmount

    # Update Method
    # Moves the net and removes it if it travels too far off screen.
    def update(self, screen):

        self.x += self.vx
        self.y += self.vy

        screenWidth, screenHeight = screen.get_size()
        margin = 80

        if self.x < -margin or self.x > screenWidth + margin:
            self.active = False

        if self.y < -margin or self.y > screenHeight + margin:
            self.active = False

    # Draw Method
    # Draws the object as a simple net/trap shape.
    def draw(self, screen):

        # Main net circle
        pygame.draw.circle(
            screen,
            self.color,
            (int(self.x), int(self.y)),
            int(self.radius),
            2
        )

        # Cross lines to make it feel like a net or trap
        pygame.draw.line(
            screen,
            self.color,
            (int(self.x - self.radius), int(self.y)),
            (int(self.x + self.radius), int(self.y)),
            2
        )

        pygame.draw.line(
            screen,
            self.color,
            (int(self.x), int(self.y - self.radius)),
            (int(self.x), int(self.y + self.radius)),
            2
        )

    # Damage Method
    # Lowers the player's well-being.
    def damagePlayer(self, player):
        player.takeDamage(self.damageAmount)

    # Destroy Method
    # Makes the net inactive so the game removes it.
    def destroy(self):
        self.active = False

    # Print Properties Method
    def printProperties(self):
        print("Net Projectile Properties:")
        print("Position:", self.x, self.y)
        print("Velocity:", self.vx, self.vy)
        print("Damage Amount:", self.damageAmount)
        print("Active:", self.active)


# ========= Testing =========

if __name__ == "__main__":
    n1 = NetProjectile(100, 100, 3, 0)
    n1.printProperties()


# Thank you for reading the code. The author would appreciate your feedback.