"""
Author: Given Muwowo
Class: Object Oriented Programming: Game Design
Date: 06/03/2026
Project: Final Game Project, whalePulse
File Name: playerWhale.py
Purpose: To define the PlayerWhale class for the whalePulse game.
Higher Level Goal: To create a controllable whale-presence with well-being, movement, score, and signal ability so the player can interact with the ecosystem.
AI Usage Statement: I used AI as a learning tool while working on this project. I wrote and tested the code, made my own decisions about the game, and I am responsible for the final work.
"""

# ==== Import Statements ====
import pygame
import math
from agent import Agent


# ========= Classes =========

class PlayerWhale(Agent):
    """
    Represents the player-controlled whale-presence in the ecosystem.
    The player is drawn as a simple circular signal body instead of a realistic whale image.
    """

    def __init__(self, x, y, speed=5, color=(0, 150, 255), radius=26):

        super().__init__(x, y, color, radius)

        self.speed = speed
        self.wellBeing = 100
        self.maxWellBeing = 100
        self.useWellBeingColor = True
        self.score = 0

        self.signalCooldown = 0
        self.signalCooldownMax = 45

        self.visualPulseTimer = 0

    # ===== Getter Methods =====

    def get_speed(self):
        return self.speed

    def get_wellBeing(self):
        return self.wellBeing

    def get_maxWellBeing(self):
        return self.maxWellBeing

    def get_score(self):
        return self.score

    def get_signalCooldown(self):
        return self.signalCooldown

    # ===== Setter Methods =====

    def set_speed(self, speed):
        self.speed = speed

    def set_wellBeing(self, wellBeing):
        self.wellBeing = wellBeing

    def set_maxWellBeing(self, maxWellBeing):
        self.maxWellBeing = maxWellBeing

    def set_score(self, score):
        self.score = score

    def set_signalCooldown(self, signalCooldown):
        self.signalCooldown = signalCooldown

    # Move Method
    # Uses arrow keys or WASD to move the player whale-presence.
    def move(self, keys, screenWidth, screenHeight):

        if keys[pygame.K_LEFT] or keys[pygame.K_a]:
            self.x -= self.speed

        if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            self.x += self.speed

        if keys[pygame.K_UP] or keys[pygame.K_w]:
            self.y -= self.speed

        if keys[pygame.K_DOWN] or keys[pygame.K_s]:
            self.y += self.speed

        # Boundary constraints
        if self.x - self.radius < 0:
            self.x = self.radius

        if self.x + self.radius > screenWidth:
            self.x = screenWidth - self.radius

        if self.y - self.radius < 0:
            self.y = self.radius

        if self.y + self.radius > screenHeight:
            self.y = screenHeight - self.radius

    # Update Cooldown Method
    def updateSignalCooldown(self):
        if self.signalCooldown > 0:
            self.signalCooldown -= 1

    # Update Visual Pulse Method
    # Gives the player a soft breathing/signal animation.
    def updateVisualPulse(self):
        self.visualPulseTimer += 1

    # Can Signal Method
    def canSignal(self):
        return self.signalCooldown <= 0 and self.isAlive()

    # Use Signal Method
    def useSignal(self):
        self.signalCooldown = self.signalCooldownMax

    # Draw Method
    # Draws the player as a circular whale-presence with a soft pulse ring.
    def draw(self, screen):

        if self.useWellBeingColor:

            if self.wellBeing > 70:
                self.color = (0, 150, 255)

            elif self.wellBeing > 30:
                self.color = (255, 220, 0)

            elif self.wellBeing > 0:
                self.color = (255, 80, 80)

            else:
                self.color = (100, 100, 100)

        # Breathing signal ring
        pulseSize = 6 + int(4 * math.sin(self.visualPulseTimer * 0.12))
        outerRadius = self.radius + pulseSize

        pygame.draw.circle(
            screen,
            (120, 220, 255),
            (int(self.x), int(self.y)),
            int(outerRadius),
            2
        )

        # Signal-ready ring
        if self.canSignal():
            pygame.draw.circle(
                screen,
                (200, 245, 255),
                (int(self.x), int(self.y)),
                int(self.radius + 13),
                1
            )

        # Main whale-presence body
        pygame.draw.circle(
            screen,
            self.color,
            (int(self.x), int(self.y)),
            int(self.radius)
        )

        # Inner glow, not an eye
        pygame.draw.circle(
            screen,
            (220, 245, 255),
            (int(self.x), int(self.y)),
            7
        )

    # Take Damage Method
    def takeDamage(self, amount):
        self.wellBeing -= amount

        if self.wellBeing < 0:
            self.wellBeing = 0

    # Heal Method
    def heal(self, amount):
        self.wellBeing += amount

        if self.wellBeing > self.maxWellBeing:
            self.wellBeing = self.maxWellBeing

    # Status Method
    def isAlive(self):
        return self.wellBeing > 0

    # Add Score Method
    def addScore(self, amount):
        self.score += amount

    # Reset Method
    def reset(self, x, y):
        self.x = x
        self.y = y
        self.wellBeing = self.maxWellBeing
        self.score = 0
        self.signalCooldown = 0
        self.visualPulseTimer = 0

    # Print Properties Method
    def printProperties(self):
        print("Player Whale Properties:")
        print("Position:", self.x, self.y)
        print("Speed:", self.speed)
        print("Color:", self.color)
        print("Radius:", self.radius)
        print("Well-being:", self.wellBeing)
        print("Score:", self.score)
        print("Signal Cooldown:", self.signalCooldown)


# ========= Testing =========

if __name__ == "__main__":
    p1 = PlayerWhale(100, 100)
    p1.printProperties()


# Thank you for reading the code. The author would appreciate your feedback.