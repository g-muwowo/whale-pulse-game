"""
Author: Given Muwowo
Class: Object Oriented Programming: Game Design
Date: 06/03/2026
Project: Final Game Project, WhalePulseChallenge
File Name: game.py
Purpose: To define the Game class that manages the WhalePulseChallenge version.
Higher Level Goal: To connect the player, agents, food, signal pulse, nets, scoring, endless waves, visual feedback, and game states into one playable abstract whale ecosystem game.
AI Usage Statement: I used AI as a learning tool while working on this project. I wrote and tested the code, made my own decisions about the game, and I am responsible for the final work.
"""

# ==== Import Statements ====
import pygame
import random
import asyncio
from playerWhale import PlayerWhale
from whaleAgent import WhaleAgent
from disturbanceAgent import DisturbanceAgent
from foodAgent import FoodAgent
from signalPulse import SignalPulse
from netProjectile import NetProjectile
from floatingText import FloatingText
from scoreSystem import ScoreSystem


# ========= Classes =========

class Game:
    """
    Represents the main WhalePulseChallenge game manager.
    The Game class runs the loop, handles input, updates objects, draws the screen,
    and manages the different game states.
    """

    def __init__(self):

        # Initialize pygame
        pygame.init()

        # Screen setup
        self.x = 1280
        self.y = 720
        self.screen = pygame.display.set_mode((self.x, self.y))
        pygame.display.set_caption("WhalePulseChallenge, Given Muwowo")

        # Clock and fonts
        self.clock = pygame.time.Clock()
        self.font = pygame.font.SysFont(None, 26)
        self.smallFont = pygame.font.SysFont(None, 22)
        self.bigFont = pygame.font.SysFont(None, 52)

        # Score system
        self.scoreSystem = ScoreSystem()

        # Game state
        self.running = True
        self.gameState = "start"
        self.playerName = ""

        # Contact timers
        self.lastDamageTime = 0
        self.lastHealTime = 0
        self.damageDelay = 450
        self.healDelay = 700

        # Endless wave system
        self.wave = 1
        self.waveStartTime = 0
        self.waveDuration = 18000

        # Net system
        self.lastNetTime = 0
        self.netDelay = 1600

        # Survival score
        self.lastSurvivalScoreTime = 0

        # Streak system
        self.recentScoreTimes = []
        self.lastStreakTime = 0
        self.streakWindow = 5000

        # Help system
        self.showHelp = False
        self.helpTimer = 0
        self.helpDelay = 120

        # Create first game objects
        self.setupGameObjects()

    # Setup Game Objects Method
    # Creates or resets the player, agents, food, signal pulses, nets, and feedback text.
    def setupGameObjects(self):

        screenWidth = self.screen.get_width()
        screenHeight = self.screen.get_height()

        # Player whale-presence
        self.player = PlayerWhale(screenWidth // 2, screenHeight // 2)

        # Ecosystem agents
        self.agents = [
            WhaleAgent(150, 150),
            DisturbanceAgent(screenWidth - 180, screenHeight // 2)
        ]

        # Food/energy agents
        self.foodAgents = [
            FoodAgent(220, 420),
            FoodAgent(500, 180),
            FoodAgent(650, 480)
        ]

        # Moving hazards and visual effects
        self.signalPulses = []
        self.netProjectiles = []
        self.floatingTexts = []

        # Reset wave and timers
        self.wave = 1
        self.waveStartTime = pygame.time.get_ticks()

        self.lastDamageTime = 0
        self.lastHealTime = 0
        self.lastNetTime = 0
        self.lastSurvivalScoreTime = pygame.time.get_ticks()

        self.recentScoreTimes = []
        self.lastStreakTime = 0

    # Difficulty Method
    # Difficulty increases endlessly, but the increase gets gentler in higher waves.
    def getDifficulty(self):

        difficulty = 1 + (self.wave ** 0.55) * 0.45

        return difficulty

    # Restart Method
    # Restarts the game after the leaderboard screen.
    def restart(self):

        self.playerName = ""
        self.gameState = "playing"
        self.setupGameObjects()

    # Add Floating Text Method
    # Adds temporary visual feedback to the screen.
    def addFloatingText(self, x, y, message, color=(255, 255, 255), life=70):

        self.floatingTexts.append(FloatingText(x, y, message, color, life))

    # Register Recent Points Method
    # Tracks fast scoring so the game can celebrate streaks.
    def registerRecentPoints(self, amount):

        currentTime = pygame.time.get_ticks()

        for i in range(amount):
            self.recentScoreTimes.append(currentTime)

        self.recentScoreTimes = [
            scoreTime for scoreTime in self.recentScoreTimes
            if currentTime - scoreTime <= self.streakWindow
        ]

        # Celebration: 5 points in 5 seconds.
        if len(self.recentScoreTimes) >= 5 and currentTime - self.lastStreakTime > 5000:

            self.player.addScore(5)
            self.lastStreakTime = currentTime
            self.recentScoreTimes = []

            self.addFloatingText(
                self.player.get_x() - 70,
                self.player.get_y() - 55,
                "PULSE STREAK! +5",
                (255, 255, 120),
                100
            )

            # Celebration ring around the player
            self.signalPulses.append(SignalPulse(self.player.get_x(), self.player.get_y()))

    # Add Score Method
    # Adds score and visual feedback.
    def addScore(self, amount, x=None, y=None, message=None, color=(255, 255, 255), countForStreak=True):

        self.player.addScore(amount)

        if x is not None and y is not None:
            if message is None:
                message = "+" + str(amount)

            self.addFloatingText(x, y, message, color)

        if countForStreak:
            self.registerRecentPoints(amount)

    # Event Method
    # Handles quit, resize, mouse help, keyboard input, pulse, name entry, and restart.
    def handleEvents(self):

        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                self.running = False

            elif event.type == pygame.VIDEORESIZE:
                pass

            elif event.type == pygame.MOUSEBUTTONDOWN:
                if self.gameState == "playing":
                    if self.getHelpButton().collidepoint(event.pos):
                        self.showHelp = True
                        self.helpTimer = self.helpDelay

            elif event.type == pygame.KEYDOWN:

                if self.gameState == "start":
                    if event.key == pygame.K_SPACE:
                        self.gameState = "playing"
                        self.waveStartTime = pygame.time.get_ticks()

                elif self.gameState == "playing":

                    if event.key == pygame.K_SPACE and self.player.canSignal():
                        pulse = SignalPulse(self.player.get_x(), self.player.get_y())
                        self.signalPulses.append(pulse)
                        self.player.useSignal()

                elif self.gameState == "name_input":

                    if event.key == pygame.K_RETURN:
                        self.scoreSystem.saveScore(self.playerName, self.player.get_score())
                        self.gameState = "leaderboard"

                    elif event.key == pygame.K_BACKSPACE:
                        self.playerName = self.playerName[:-1]

                    else:
                        # Keep names short and readable.
                        if len(self.playerName) < 12:
                            self.playerName += event.unicode

                elif self.gameState == "leaderboard":

                    if event.key == pygame.K_r:
                        self.restart()

    # Update Method
    # Updates gameplay objects and checks interactions.
    def update(self):

        if self.gameState != "playing":
            return

        screenWidth = self.screen.get_width()
        screenHeight = self.screen.get_height()
        currentTime = pygame.time.get_ticks()
        keys = pygame.key.get_pressed()

        # Player movement and animation
        if self.player.isAlive():
            self.player.move(keys, screenWidth, screenHeight)
            self.player.updateSignalCooldown()
            self.player.updateVisualPulse()

        # Update agents
        for agent in self.agents:
            agent.update(self.screen)

        # Update food
        for food in self.foodAgents:
            food.update(self.screen)

        # Update signal pulses
        for pulse in self.signalPulses:
            pulse.update()

        # Update nets
        for net in self.netProjectiles:
            net.update(self.screen)

        # Update floating text
        for text in self.floatingTexts:
            text.update()

        # Remove inactive objects
        self.signalPulses = [pulse for pulse in self.signalPulses if pulse.get_active()]
        self.netProjectiles = [net for net in self.netProjectiles if net.get_active()]
        self.floatingTexts = [text for text in self.floatingTexts if text.get_active()]

        # Interactions
        self.handleAgentCollisions(currentTime)
        self.handleFoodCollisions()
        self.handleNetCollisions(currentTime)
        self.handlePulseCollisions()

        # Systems
        self.spawnNets(currentTime)
        self.updateWave(currentTime)
        self.updateSurvivalScore(currentTime)
        self.updateHelpButton()

        # Game over
        if not self.player.isAlive():
            self.gameState = "name_input"

    # Handle Agent Collisions Method
    # Handles player contact with green support and red disturbance.
    def handleAgentCollisions(self, currentTime):

        for agent in self.agents:

            if agent.isColliding(self.player):

                if isinstance(agent, WhaleAgent):
                    if currentTime - self.lastHealTime > self.healDelay:
                        agent.supportPlayer(self.player)
                        self.lastHealTime = currentTime

                        self.addFloatingText(
                            self.player.get_x() - 20,
                            self.player.get_y() - 45,
                            "+ support",
                            (0, 255, 150)
                        )

                elif isinstance(agent, DisturbanceAgent):
                    if currentTime - self.lastDamageTime > self.damageDelay:
                        agent.damagePlayer(self.player)
                        self.lastDamageTime = currentTime

                        self.addFloatingText(
                            self.player.get_x() - 25,
                            self.player.get_y() - 45,
                            "- danger",
                            (255, 100, 100)
                        )

    # Handle Food Collisions Method
    # Handles player collecting yellow or golden food.
    def handleFoodCollisions(self):

        for food in self.foodAgents:

            if food.isColliding(self.player):

                foodX = food.get_x()
                foodY = food.get_y()

                points = food.collect(self.player, self.screen)

                if points >= 5:
                    self.addFloatingText(
                        foodX - 25,
                        foodY - 25,
                        "+5 GOLD",
                        (255, 230, 0)
                    )

                else:
                    self.addFloatingText(
                        foodX - 10,
                        foodY - 25,
                        "+1",
                        (255, 230, 0)
                    )

                self.registerRecentPoints(points)

    # Handle Net Collisions Method
    # Handles nets hitting the player.
    def handleNetCollisions(self, currentTime):

        for net in self.netProjectiles:

            if net.isColliding(self.player):

                if currentTime - self.lastDamageTime > self.damageDelay:
                    net.damagePlayer(self.player)
                    self.lastDamageTime = currentTime
                    net.destroy()

                    self.addFloatingText(
                        self.player.get_x() - 25,
                        self.player.get_y() - 45,
                        "- net",
                        (220, 220, 220)
                    )

    # Handle Pulse Collisions Method
    # Handles signal pulse slowing disturbances and destroying nets.
    def handlePulseCollisions(self):

        for pulse in self.signalPulses:

            # Pulse slows red disturbances.
            for agent in self.agents:
                if isinstance(agent, DisturbanceAgent):
                    if pulse.isColliding(agent):
                        pulse.affectDisturbance(agent)

            # Pulse destroys nets.
            for net in self.netProjectiles:
                if pulse.isColliding(net) and net.get_active():
                    netX = net.get_x()
                    netY = net.get_y()
                    net.destroy()

                    self.addScore(
                        2,
                        netX - 20,
                        netY - 20,
                        "+2 pulse",
                        (180, 230, 255),
                        True
                    )

    # Spawn Nets Method
    # Spawns moving net projectiles from screen edges.
    def spawnNets(self, currentTime):

        difficulty = self.getDifficulty()

        # Nets come faster as difficulty rises, but the delay never becomes too low.
        delay = max(650, int(self.netDelay / difficulty))

        if currentTime - self.lastNetTime > delay:

            screenWidth = self.screen.get_width()
            screenHeight = self.screen.get_height()

            side = random.choice(["left", "right", "top", "bottom"])

            # Net speed rises with difficulty, but not brutally.
            speed = 2.0 + difficulty * 0.95

            if side == "left":
                x = -20
                y = random.randint(80, max(80, screenHeight - 80))
                vx = speed
                vy = random.uniform(-1.1, 1.1)

            elif side == "right":
                x = screenWidth + 20
                y = random.randint(80, max(80, screenHeight - 80))
                vx = -speed
                vy = random.uniform(-1.1, 1.1)

            elif side == "top":
                x = random.randint(80, max(80, screenWidth - 80))
                y = -20
                vx = random.uniform(-1.1, 1.1)
                vy = speed

            else:
                x = random.randint(80, max(80, screenWidth - 80))
                y = screenHeight + 20
                vx = random.uniform(-1.1, 1.1)
                vy = -speed

            net = NetProjectile(x, y, vx, vy)
            net.set_damageAmount(int(13 + difficulty * 3))
            self.netProjectiles.append(net)

            self.lastNetTime = currentTime

    # Update Wave Method
    # Moves to the next endless wave when the timer runs out.
    def updateWave(self, currentTime):

        elapsed = currentTime - self.waveStartTime

        if elapsed >= self.waveDuration:
            self.nextWave(currentTime)

    # Next Wave Method
    # Makes the game harder, gives a reward, and creates achievement moments.
    def nextWave(self, currentTime):

        self.wave += 1
        self.waveStartTime = currentTime

        centerX = self.screen.get_width() // 2
        centerY = self.screen.get_height() // 2

        # Milestone rewards make the player want to keep reaching new waves.
        if self.wave % 10 == 0:
            bonus = 25
            message = "WAVE " + str(self.wave) + " LEGEND! +" + str(bonus)
            color = (255, 180, 255)

        elif self.wave % 5 == 0:
            bonus = 15
            message = "MILESTONE WAVE " + str(self.wave) + "! +" + str(bonus)
            color = (255, 255, 120)

        elif self.wave % 3 == 0:
            bonus = 8
            message = "DEEPER WATER +" + str(bonus)
            color = (180, 230, 255)

        else:
            bonus = 5
            message = "WAVE " + str(self.wave) + "! +" + str(bonus)
            color = (255, 255, 255)

        self.player.addScore(bonus)

        self.addFloatingText(
            centerX - 95,
            centerY,
            message,
            color,
            120
        )

        # Celebration ring around the player at wave changes.
        self.signalPulses.append(SignalPulse(self.player.get_x(), self.player.get_y()))

        # Existing disturbances get harder, but not as violently as before.
        for agent in self.agents:
            if isinstance(agent, DisturbanceAgent):
                agent.speedUp(1.06)

        # Add new disturbances sometimes, not every wave.
        # This keeps later waves challenging without becoming impossible too quickly.
        if self.wave in [2, 4] or self.wave % 6 == 0:

            screenWidth = self.screen.get_width()
            screenHeight = self.screen.get_height()

            newDisturbance = DisturbanceAgent(
                random.randint(80, max(80, screenWidth - 80)),
                random.randint(80, max(80, screenHeight - 80))
            )

            difficulty = self.getDifficulty()
            newDisturbance.set_damageAmount(int(10 + difficulty * 3))

            self.agents.append(newDisturbance)

    # Update Survival Score Method
    # Adds score for staying alive over time.
    def updateSurvivalScore(self, currentTime):

        if currentTime - self.lastSurvivalScoreTime > 1000:
            self.player.addScore(1)
            self.lastSurvivalScoreTime = currentTime

    # Update Help Button Method
    # Shows help when the player touches the button, or after mouse click.
    def updateHelpButton(self):

        helpButton = self.getHelpButton()

        playerRect = pygame.Rect(
            int(self.player.get_x() - self.player.get_radius()),
            int(self.player.get_y() - self.player.get_radius()),
            int(self.player.get_radius() * 2),
            int(self.player.get_radius() * 2)
        )

        if playerRect.colliderect(helpButton):
            self.showHelp = True
            self.helpTimer = self.helpDelay

        else:
            if self.helpTimer > 0:
                self.helpTimer -= 1
            else:
                self.showHelp = False

    # Get Help Button Method
    def getHelpButton(self):

        screenWidth = self.screen.get_width()

        return pygame.Rect(screenWidth - 70, 20, 50, 35)

    # Draw Well-being Bar Method
    def drawWellBeingBar(self):

        xBar = 20
        yBar = 20
        widthBar = 220
        heightBar = 22

        wellBeingPercent = max(0, min(1, self.player.get_wellBeing() / self.player.get_maxWellBeing()))
        currentWidth = widthBar * wellBeingPercent

        pygame.draw.rect(self.screen, (160, 30, 30), (xBar, yBar, widthBar, heightBar))
        pygame.draw.rect(self.screen, (0, 170, 255), (xBar, yBar, currentWidth, heightBar))
        pygame.draw.rect(self.screen, (255, 255, 255), (xBar, yBar, widthBar, heightBar), 2)

        text = self.font.render("Well-being: " + str(int(self.player.get_wellBeing())), True, (255, 255, 255))
        self.screen.blit(text, (20, 50))

    # Draw Score Method
    def drawScore(self):

        scoreText = self.font.render("Score: " + str(self.player.get_score()), True, (255, 255, 255))
        waveText = self.font.render("Wave: " + str(self.wave), True, (255, 255, 255))

        remaining = max(0, int((self.waveDuration - (pygame.time.get_ticks() - self.waveStartTime)) / 1000))
        timeText = self.font.render("Next wave in: " + str(remaining), True, (255, 255, 255))

        pulseText = "Pulse: ready"

        if not self.player.canSignal():
            pulseText = "Pulse: cooling"

        pulseDisplay = self.font.render(pulseText, True, (180, 230, 255))

        difficultyText = self.smallFont.render("Difficulty: " + str(round(self.getDifficulty(), 2)), True, (210, 210, 210))

        self.screen.blit(scoreText, (20, 78))
        self.screen.blit(waveText, (20, 104))
        self.screen.blit(timeText, (20, 130))
        self.screen.blit(pulseDisplay, (20, 156))
        self.screen.blit(difficultyText, (20, 182))

    # Draw Help Button Method
    def drawHelpButton(self):

        helpButton = self.getHelpButton()

        pygame.draw.rect(self.screen, (230, 240, 250), helpButton)
        pygame.draw.rect(self.screen, (0, 0, 0), helpButton, 2)

        helpText = self.font.render("?", True, (0, 0, 0))
        self.screen.blit(helpText, (helpButton.x + 18, helpButton.y + 8))

    # Draw Help Box Method
    def drawHelpBox(self):

        xBox = 195
        yBox = 70
        widthBox = 430
        heightBox = 165

        pygame.draw.rect(self.screen, (20, 40, 60), (xBox, yBox, widthBox, heightBox))
        pygame.draw.rect(self.screen, (255, 255, 255), (xBox, yBox, widthBox, heightBox), 2)

        lines = [
            ("Yellow = energy / score", (255, 230, 0)),
            ("Green = support", (0, 255, 150)),
            ("Red = disturbance", (255, 100, 100)),
            ("Gray nets hurt you", (220, 220, 220)),
            ("SPACE = pulse. Pulse destroys nets.", (180, 230, 255)),
            ("Survive endlessly. Reach milestone waves.", (255, 255, 255))
        ]

        y = yBox + 13

        for text, color in lines:
            line = self.font.render(text, True, color)
            self.screen.blit(line, (xBox + 15, y))
            y += 24

    # Draw Start Screen Method
    def drawStartScreen(self):

        self.screen.fill((0, 45, 85))

        screenWidth = self.screen.get_width()
        screenHeight = self.screen.get_height()

        title = self.bigFont.render("WhalePulse", True, (255, 255, 255))
        subtitle = self.smallFont.render("Endless abstract whale ecosystem game", True, (180, 230, 255))

        line1 = self.smallFont.render("Yellow = energy. Green = support.", True, (255, 255, 255))
        line2 = self.smallFont.render("Red = disturbance. Gray nets hurt.", True, (255, 255, 255))
        line3 = self.smallFont.render("SPACE = pulse. Pulse destroys nets.", True, (255, 255, 0))
        line4 = self.smallFont.render("Survive endless waves.", True, (255, 255, 255))
        start = self.font.render("Press SPACE to start", True, (255, 255, 255))

        y = int(screenHeight * 0.18)

        self.screen.blit(title, title.get_rect(center=(screenWidth // 2, y)))
        self.screen.blit(subtitle, subtitle.get_rect(center=(screenWidth // 2, y + 45)))

        self.screen.blit(line1, line1.get_rect(center=(screenWidth // 2, y + 105)))
        self.screen.blit(line2, line2.get_rect(center=(screenWidth // 2, y + 132)))
        self.screen.blit(line3, line3.get_rect(center=(screenWidth // 2, y + 159)))
        self.screen.blit(line4, line4.get_rect(center=(screenWidth // 2, y + 186)))

        self.screen.blit(start, start.get_rect(center=(screenWidth // 2, y + 245)))

        pygame.display.update()


    # Draw Name Input Screen Method
    def drawNameInputScreen(self):

        self.screen.fill((0, 45, 85))

        screenWidth = self.screen.get_width()
        screenHeight = self.screen.get_height()

        title = self.bigFont.render("Game Over", True, (255, 100, 100))
        scoreText = self.font.render("Score: " + str(self.player.get_score()), True, (255, 255, 255))
        waveText = self.font.render("Wave " + str(self.wave), True, (255, 255, 120))
        instruction = self.font.render("Enter your name:", True, (255, 255, 255))
        nameText = self.font.render(self.playerName + "_", True, (255, 255, 0))
        enterText = self.smallFont.render("Press ENTER to save", True, (255, 255, 255))

        y = int(screenHeight * 0.18)

        self.screen.blit(title, title.get_rect(center=(screenWidth // 2, y)))
        self.screen.blit(scoreText, scoreText.get_rect(center=(screenWidth // 2, y + 60)))
        self.screen.blit(waveText, waveText.get_rect(center=(screenWidth // 2, y + 92)))
        self.screen.blit(instruction, instruction.get_rect(center=(screenWidth // 2, y + 145)))
        self.screen.blit(nameText, nameText.get_rect(center=(screenWidth // 2, y + 185)))
        self.screen.blit(enterText, enterText.get_rect(center=(screenWidth // 2, y + 235)))

        pygame.display.update()

    # Draw Leaderboard Screen Method
    def drawLeaderboardScreen(self):

        self.screen.fill((0, 45, 85))

        screenWidth = self.screen.get_width()
        screenHeight = self.screen.get_height()

        title = self.bigFont.render("Leaderboard", True, (255, 255, 255))
        self.screen.blit(title, title.get_rect(center=(screenWidth // 2, int(screenHeight * 0.16))))

        scores = self.scoreSystem.getTopScores(5)

        y = int(screenHeight * 0.30)
        place = 1

        if len(scores) == 0:
            noScoreText = self.font.render("No scores yet.", True, (255, 255, 255))
            self.screen.blit(noScoreText, noScoreText.get_rect(center=(screenWidth // 2, y)))

        else:
            for name, score in scores:
                line = self.font.render(str(place) + ". " + name + " - " + str(score), True, (255, 255, 255))
                self.screen.blit(line, line.get_rect(center=(screenWidth // 2, y)))
                y += 32
                place += 1

        restart = self.font.render("Press R to play again", True, (255, 255, 0))
        self.screen.blit(restart, restart.get_rect(center=(screenWidth // 2, int(screenHeight * 0.86))))

        pygame.display.update()

    # Draw Method
    # Draws special screens or gameplay.
    def draw(self):

        if self.gameState == "start":
            self.drawStartScreen()
            return

        if self.gameState == "name_input":
            self.drawNameInputScreen()
            return

        if self.gameState == "leaderboard":
            self.drawLeaderboardScreen()
            return

        # Background changes by wave range.
        if self.wave < 3:
            self.screen.fill((0, 60, 100))

        elif self.wave < 6:
            self.screen.fill((25, 45, 90))

        elif self.wave < 10:
            self.screen.fill((35, 35, 85))

        elif self.wave < 15:
            self.screen.fill((45, 30, 70))

        else:
            self.screen.fill((55, 25, 60))

        # Draw objects
        for food in self.foodAgents:
            food.draw(self.screen)

        for agent in self.agents:
            agent.draw(self.screen)

        for net in self.netProjectiles:
            net.draw(self.screen)

        for pulse in self.signalPulses:
            pulse.draw(self.screen)

        self.player.draw(self.screen)

        for text in self.floatingTexts:
            text.draw(self.screen, self.font)

        # Draw UI
        self.drawWellBeingBar()
        self.drawScore()
        self.drawHelpButton()

        if self.showHelp:
            self.drawHelpBox()

        pygame.display.update()

    # Run Method
    # Main game loop.
    # This version is async so the game can run in a browser through Pygbag.
    async def run(self):

        while self.running:

            self.handleEvents()
            self.update()
            self.draw()

            self.clock.tick(60)

            # Gives control back to the browser so the page stays responsive.
            await asyncio.sleep(0)

        pygame.quit()

# Thank you for reading the code. The author would appreciate your feedback.