"""
Author: Given Muwowo
Class: Object Oriented Programming: Game Design
Date: 06/03/2026
Project: Final Game Project, WhalePulseWeb
File Name: scoreSystem.py
Purpose: To define the ScoreSystem class for the web version of the WhalePulse game.
Higher Level Goal: To keep player names and scores during the current browser session so the game can still show a simple leaderboard without depending on desktop file saving.
AI Usage Statement: I used AI as a learning tool while working on this project. I wrote and tested the code, made my own decisions about the game, and I am responsible for the final work.
"""

# ========= Classes =========

class ScoreSystem:
    """
    Represents a simple session-only score and leaderboard system.
    This web version does not save scores to a text file.
    """

    def __init__(self, filename="scores.txt"):

        # The filename is kept so the class still matches the desktop version,
        # but the web version does not use it.
        self.filename = filename
        self.scores = []

    # Load Scores Method
    # Web version keeps scores only during the current browser session.
    def loadScores(self):
        pass

    # Save Score Method
    # Saves one name and score only while the game is running.
    def saveScore(self, name, score):

        if name.strip() == "":
            name = "Player"

        name = name.replace(",", "")

        self.scores.append((name, score))
        self.scores.sort(key=lambda item: item[1], reverse=True)

    # Get Top Scores Method
    # Returns the highest scores from the current session.
    def getTopScores(self, limit=5):
        return self.scores[:limit]

    # Clear Scores Method
    # This is optional and can be used for testing.
    def clearScores(self):
        self.scores = []

    # Print Scores Method
    def printScores(self):

        print("Leaderboard:")

        place = 1

        for name, score in self.getTopScores():
            print(str(place) + ". " + name + " - " + str(score))
            place += 1


# ========= Testing =========

if __name__ == "__main__":
    scoreSystem = ScoreSystem()
    scoreSystem.saveScore("Test Player", 10)
    scoreSystem.printScores()


# Thank you for reading the code. The author would appreciate your feedback.